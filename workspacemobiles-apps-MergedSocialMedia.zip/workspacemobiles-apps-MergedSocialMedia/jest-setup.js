import {NativeModules} from 'react-native';

NativeModules.ReactLocalization = {
  language: 'en',
};
