import React, {Component} from 'react';
import {View} from 'react-native';
import {Container} from 'native-base';

class Calender extends Component {
  render() {
    return <Container testID="calenderEvents" />;
  }
}

export default Calender;
