// import {PatientList} from './index.js';

test('tests run correctly', () => {
  //   expect(PatientList.hello()).toEqual('hii');
});
