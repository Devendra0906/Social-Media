import AddPatient, {test} from './index.js';

describe('Testing the reducer AddListPatientReducer', () => {
  it('hide data picker', () => {
    // const Header = (AddPatient.renderHeader = jest.fn());
    // expect(Header).toHaveBeenCalledTimes(1);
    // // expect(person).toEqual(expected);
  });
});
