const ReceivedFeedbackList = [
  {
    user_id: 1,
    name: 'Anas Laffet',
    img: './../../../../../assets/images/contacts/atul.png',
    feedbacks: [
      {
        name: 'orientation',
        icon: 'star'
      },
      {
        name: 'Relationships',
        icon: 'cap'
      },
      {
        name: 'Service',
        icon: 'star'
      },
      {
        name: 'ownership',
        icon: 'medal'
      },
      {
        name: 'proactive',
        icon: 'star'
      }
    ]
  },
  {
    user_id: 2,
    name: 'Fouad Omri',
    img: './../../../../../assets/images/contacts/batman.jpg',
    feedbacks: [
      {
        name: 'orientation',
        icon: 'star'
      },
      {
        name: 'Relationships',
        icon: 'cap'
      }
    ]
  },
  {
    user_id: 3,
    name: 'Chetan Godhani',
    img: './../../../../../assets/images/contacts/captain-america.jpg',
    feedbacks: [
      {
        name: 'orientation',
        icon: 'star'
      },
      {
        name: 'Relationships',
        icon: 'star'
      },
      {
        name: 'Service',
        icon: 'star'
      }
    ]
  },
  {
    user_id: 4,
    name: 'Fouad Omri',
    img: './../../../../../assets/images/contacts/batman.jpg',
    feedbacks: [
      {
        name: 'orientation',
        icon: 'star'
      },
      {
        name: 'Relationships',
        icon: 'cap'
      }
    ]
  },
  {
    user_id: 5,
    name: 'Fouad Omri',
    img: './../../../../../assets/images/contacts/batman.jpg',
    feedbacks: [
      {
        name: 'orientation',
        icon: 'star'
      },
      {
        name: 'Relationships',
        icon: 'cap'
      }
    ]
  },
  {
    user_id: 6,
    name: 'Fouad Omri',
    img: './../../../../../assets/images/contacts/batman.jpg',
    feedbacks: [
      {
        name: 'orientation',
        icon: 'star'
      },
      {
        name: 'Relationships',
        icon: 'cap'
      }
    ]
  },
  {
    user_id: 7,
    name: 'Fouad Omri',
    img: './../../../../../assets/images/contacts/batman.jpg',
    feedbacks: [
      {
        name: 'orientation',
        icon: 'star'
      },
      {
        name: 'Relationships',
        icon: 'cap'
      }
    ]
  },
  {
    user_id: 8,
    name: 'Fouad Omri',
    img: './../../../../../assets/images/contacts/batman.jpg',
    feedbacks: [
      {
        name: 'orientation',
        icon: 'star'
      },
      {
        name: 'Relationships',
        icon: 'cap'
      }
    ]
  },
  {
    user_id: 9,
    name: 'Fouad Omri',
    img: './../../../../../assets/images/contacts/captain-america.jpg',
    feedbacks: [
      {
        name: 'orientation',
        icon: 'star'
      },
      {
        name: 'Relationships',
        icon: 'cap'
      }
    ]
  },
  {
    user_id: 10,
    name: 'Fouad Omri',
    img: './../../../../../assets/images/contacts/batman.jpg',
    feedbacks: [
      {
        name: 'orientation',
        icon: 'star'
      },
      {
        name: 'Relationships',
        icon: 'cap'
      }
    ]
  },
];

module.exports = ReceivedFeedbackList;