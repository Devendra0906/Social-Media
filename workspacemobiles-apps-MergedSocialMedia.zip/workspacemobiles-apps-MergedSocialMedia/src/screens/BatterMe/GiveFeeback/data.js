const totalfeedbacks = [
  {
    name: 'Agility',
    icon: []
  },
  {
    name: 'orientation',
    icon: []
  },
  {
    name: 'Relationships',
    icon: []
  },
  {
    name: 'Creative',
    icon: []
  },
  {
    name: 'ownership',
    icon: []
  },
  {
    name: 'proactive',
    icon: []
  },
  {
    name: 'Service',
    icon: []
  },
  {
    name: 'Opener',
    icon: []
  },
  {
    name: 'Emotional Intelligence',
    icon: []
  }
];

module.exports = totalfeedbacks;