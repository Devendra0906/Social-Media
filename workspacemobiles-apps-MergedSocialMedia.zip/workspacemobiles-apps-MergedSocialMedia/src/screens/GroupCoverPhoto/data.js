const cat1 = require("../../../assets/images/category/category_1.jpg");
const cat2 = require("../../../assets/images/category/category_2.jpg");
const cat3 = require("../../../assets/images/category/category_3.jpg");
const cat4 = require("../../../assets/images/category/category_4.jpg");
const cat5 = require("../../../assets/images/category/category_5.jpg");
const cat6 = require("../../../assets/images/category/category_6.jpg");
const cat7 = require("../../../assets/images/category/category_7.jpg");
const cat8 = require("../../../assets/images/category/category_8.jpg");
const cat9 = require("../../../assets/images/category/category_9.jpg");

const data = [
  cat1,
  cat2,
  cat3,
  cat4,
  cat5,
  cat6,
  cat7,
  cat8,
  cat9
];

module.exports = data;
